<!DOCTYPE html>
<html style="height:100%;  ">
 	<head>
    <meta charset="UTF-8">
    <title>E-LAT Online Test Portal</title>
    <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css'>
    <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="aa.css">
  	</head>
	
	<style>
		html, body {
  			height: 100%;
		}
		footer {
		  position: absolute;
  		  bottom: 0;
	}
	</style>
	
	<body oncontextmenu="return false" oncopy="return false" oncut="return false" onpaste="return false" style="height:100%;">

<nav class="navbar navbar-inverse">
  <div class="container-fluid" >
    <div class="navbar-header">
     <!-- <a class="navbar-brand" href="#">Logo</a>-->
    </div>
	
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">E-Lat Online Test Portal</a></li>
      </ul>
	</div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
		
		<!-------------------------------------------------------->	

<div class="col-sm-12 sidenav">
	
	<h3 style="text-align:center">Thank you...!!</h3>
       
</div>
	<div class="navbar-fixed-bottom" style="padding-top:.5%;width:100%;background-color:#555;height:35px;color:#FFFFFF;position:absolute;bottom:0px;text-align:right;padding-right:2%;">  Powered by Appexigo Technogies</div>
	</div>
    
</body>
	
	
  
</html>