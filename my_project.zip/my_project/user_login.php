<?php
	if($_POST['submit']){
	include('mysql-connect.php');
	$user_id = $_POST['username'];
	$password = $_POST['password'];
	$sql = "SELECT * FROM user WHERE user_id='$user_id' AND password='$password'";
	
	$result = $conn->query($sql);
	$n = $result->num_rows ;
	if ($n>0)
	{
		header("Location: video_pdf.php");
		session_start();
		$_SESSION['user']=$user_id;
	}
	else 
	{
		$message = "Check username or password";
		echo "<script type='text/javascript'>window.alert('$message');</script>";
	}
}

?>
<!DOCTYPE html>
<html style="height:100%;  ">
 	<head>
    <meta charset="UTF-8">
    <title>E-LAT Online Test Portal</title>
    <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css'>
    <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="aa.css">
  	</head>
	
	<body oncontextmenu="return false" oncopy="return false" oncut="return false" onpaste="return false" style="height:100%;">

<nav class="navbar navbar-inverse">
  <div class="container-fluid" >
    <div class="navbar-header">
     <!-- <a class="navbar-brand" href="#">Logo</a>-->
    </div>
	
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">E-Lat Online Test Portal</a></li>
      </ul>
	</div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
		
		<!-------------------------------------------------------->	

<div class="col-sm-12 sidenav">
	
	<div style="width:20%;margin:auto;padding: 10px;border: 3px solid #555;">
	
	<form class="form-signin" action="user_login.php" method="POST">       
		<fieldset class="scheduler-border"><legend class="scheduler-border">User login</legend>
	  
	  <input type="text" class="form-control" name="username" placeholder="Email Address" required="" autofocus="" />
      <input type="password" class="form-control" name="password" placeholder="Password" required=""/>      
      
      <!--<button class="btn btn-lg btn-primary btn-block" type="submit">Login</button> --><br>
	   <input type="submit" name="submit" value="Submit" style="width:100%;background-color:#555;height:35px;border-radius:6px;color:#FFFFFF"/>
		</fieldset>
    </form>
       
</div>
	<div class="navbar-fixed-bottom" style="padding-top:.5%;width:100%;background-color:#555;height:35px;color:#FFFFFF;position:absolute;bottom:0px;text-align:right;padding-right:2%;">  Powered by Appexigo Technogies</div>
	</div>
    
</body>
	
	
  
</html>