<?php 
	session_start();
	$user=$_SESSION['user'];
?>

<!DOCTYPE html>
<html style="height:100%;">
 	<head>
    <meta charset="UTF-8">
    <title>User Login</title>
    <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css'>
    <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="aa.css">
  	</head>
	
	<body oncontextmenu="return false" oncopy="return false" oncut="return false" onpaste="return false" style="height:100%;">

 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">E-Lat Online Test Portal</a></li>
      <li><a href="#">Page 3</a></li>
    </ul>
    
    <ul class="nav navbar-nav navbar-right">
      <li class="active"><a href="#">Welcome <?php echo ucfirst($user);?></a></li>
      <li><a href="#">Exam Centre: Gwalior</a></li>
    </ul>
  
  </div>
</nav>

<div class="container-fluid text-center" style="background-color:#f1f1f1">    
  <div class="row content" >
		
		<!-------------------------------------------------------->	

<div class="wrapper" style="background-color:#f1f1f1">
	<br>
	<div class="container-fluid" >
         	<div class="row">
                <div class="col-sm-6">
					<div class="container" style="margin-left:100px;background-color:lavender;width:90%; margin:auto;padding:10px;border: 3px solid #555;height:350px ">
            	     		<video width="100%" height="96%" controls>
             			    <source src="video/video.mp4" type="video/mp4">
             		  	    <!-- <source src="movie.ogg" type="video/ogg">-->
             		  	    Your browser does not support the video tag.
            		        </video>
						<p> Choose to fullscreen to see video<p>
                	</div>
				</div>

                <div class="col-sm-6" style="background-color:lavender;">
                	<div class="container" style="margin-right:100px;background-color:lavender;width:90%; margin:auto;padding:10px;border: 3px solid #555;height:350px ">
            	    	<iframe src="video/hello.pdf" style="width:100%; height:350px;" frameborder="0"></iframe>
							<!--<object width="100%" height="400px" data="video/hello.pdf">
						</object>-->
					</div>
                </div>

         	 </div>
	</div>

	<div class="navbar-fixed-bottom" style="padding-top:.5%;width:100%;background-color:#555;height:35px;color:#FFFFFF;position:absolute;bottom:0px;text-align:right;padding-right:2%;">  Powered by Appexigo Technogies
  </div>
	</div> </div>
	<form action="index.php" method="POST">
		<input type="submit" name="submit" value="Finish" style="width:200px;background-color:#555;height:35px;border-radius:10px;color:#FFFFFF"/>
	</form>
	
</body> 
</html>