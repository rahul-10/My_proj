<?php
if($_POST['submit']){

  include('mysql-connect.php');
  $q_no = $_POST['q_no'];
  $question = $_POST['question'];
  $op1 = $_POST['op1'];
  $op2 = $_POST['op2'];
  $op3 = $_POST['op3'];
  $op4 = $_POST['op4'];
  $right_ans = $_POST['right_ans'];
	
  $sql = "SELECT * FROM question" ;
  $result = $conn->query($sql);
  $n = $result->num_rows ;    
  $n++;
  //echo $n;
  $sql = "INSERT INTO question (q_no,question, op1, op2, op3, op4,right_ans) VALUES ('$n','$question', '$op1', '$op2', '$op3', '$op4', '$right_ans')" ;

  if ($conn->query($sql) === TRUE) {
       //echo "New record created successfully";
  }
  else {
       echo "Error: " . $sql . "<br>" . $conn->error;
  }
}  // end of if 

?>
<?php
  include('mysql-connect.php');
  $sql = "SELECT * FROM question" ;
  $result = $conn->query($sql);
  $n = $result->num_rows ;    
  $n++;
  //$GLOBALS['z'] = $GLOBALS['n'] ;
 // echo $n;
?>
<html lang="en">
<head>
  <title>E-LAT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="aa.css">
</head>


<body oncontextmenu="return false" oncopy="return false" oncut="return false" onpaste="return false" >


<nav class="navbar navbar-inverse" >
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <!-- <a class="navbar-brand" href="#">Logo</a>-->
    </div>
  
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">E-Lat Online Test Portal</a></li>
      </ul>
  </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
    
    <!--------------------------------------------------------> 

<div  class="wrapper"><br>
  
  <form action="question_form.php" method="POST">
  
      Question no: <input type="text" name="q_no" size="defalut" placeholder = <?php echo $n; ?> disabled><br><br>
    Question* : <input type="text" name="question" size="defalut" required="" autofocus="" placeholder = "Here comes your question"><br><br>
    Option 1: <input type="text" name="op1" size="defalut" required="" placeholder = "Here comes 1st option"><br><br>
    Option 2: <input type="text" name="op2" size="defalut" required="" placeholder = "Here comes 2nd option"><br><br>
    Option 3: <input type="text" name="op3" size="defalut" required="" placeholder = "Here comes 3rd option"><br><br>
    Option 4: <input type="text" name="op4" size="defalut" required="" placeholder = "Here comes 4th option"><br><br>
    Right Ans: <input type="text" name="right_ans" size="defalut" required="" placeholder = "Right ans for this question"><br><br>
  
      <input type="submit" name="submit" value="Next question" />
  	  <button onclick="finish()">Finish</button>
        </form> 
     
</div>
<div class="navbar-fixed-bottom" style="padding-top:1%;width:100%;background-color:#555;height:35px;color:#FFFFFF;position:absolute;bottom:0px;text-align:right;padding-right:2%;">  Powered by Appexigo Technogies</div>
  
<script type="text/javascript">

function finish(){

	window.open("admin_dash.php","_selft") ;
}

</script>
    
</body>
</html>