<?php
	// remove all session variables
session_unset();

// destroy the session
session_destroy(); 
	if($_POST['submit']){
	include('mysql-connect.php');
	$user_id = $_POST['username'];
	$password = $_POST['password'];
	$sql = "SELECT * FROM admin WHERE user_id='$user_id' AND password='$password'";
	
	$result = $conn->query($sql);
	$n = $result->num_rows ;
	if ($n>0)
	{
		header("Location: admin_dash.php");
		session_start();
		$_SESSION['usern']=$user_id;
	}		
	else 
	{
		$message = "Check username or password";
		echo "<script type='text/javascript'>window.alert('$message');</script>";
	}
}  // end of if 

?>
<!DOCTYPE html>
<html style="height:100%;">
  

	
	<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css'>

        <link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="aa.css">
  </head>
	<style>
		html, body {
  			height: 100%;
		}
		footer {
		  position: absolute;
  		  bottom: 0;
	}
	</style>
<body oncontextmenu="return false" oncopy="return false" oncut="return false" onpaste="return false" style="height:100%;">


<nav class="navbar navbar-inverse" >
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <!-- <a class="navbar-brand" href="#">Logo</a>-->
    </div>
	
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">E-Lat Online Test Portal</a></li>
      </ul>
	</div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
		
		<!-------------------------------------------------------->	

<div class="col-sm-12 sidenav">
	
	<div style="width:20%;margin:auto;padding: 10px;border: 3px solid #555;">
	
	<form class="form-signin" action="admin_login.php" method="POST">       
		<fieldset class="scheduler-border"><legend class="scheduler-border">Admin login</legend>
	  
	  <input type="text" class="form-control" name="username" placeholder="Email Address" required="" autofocus="" />
      <input type="password" class="form-control" name="password" placeholder="Password" required=""/>      
      
      <!--<button class="btn btn-lg btn-primary btn-block" type="submit">Login</button> --><br>
	   <input type="submit" name="submit" value="Submit" style="width:100%;background-color:#555;height:35px;border-radius:6px;color:#FFFFFF"/>
		</fieldset>
    </form>
       <?php 
		//echo $newrecord;
	?>
</div>
	<div class="navbar-fixed-bottom" style="padding-top:1%;width:100%;background-color:#555;height:35px;color:#FFFFFF;position:absolute;bottom:0px;text-align:right;padding-right:2%;">  Powered by Appexigo Technogies</div>
	</div>
    
</body>
	
	
  
</html>