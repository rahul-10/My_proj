<?php 
  session_unset();
  session_start();
  $usern=$_SESSION['usern'];
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">E-Lat Online Portal</a>
    </div>
    
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Add Question<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="question_form.php">LR</a></li>
            <li><a href="#">English</a></li>
            <li><a href="#">Quanti</a></li>
          </ul>
        </li>
        <li><a href="#">Monitor Test</a></li>
        <li><a href="#">Modify Question</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Add Admin</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome! <?php echo ucfirst($usern);?></a></li>
        <li><a href="admin_login.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>        
      </ul>
    </div>
  </div>
</nav>
  
<div class="container">
  <h3>Collapsible Navbar</h3>
  <p>In this example, the navigation bar is hidden on small screens and replaced by a button in the top right corner (try to re-size this window).
  <p>Only when the button is clicked, the navigation bar will be displayed.</p>
</div>

</body>
</html>

