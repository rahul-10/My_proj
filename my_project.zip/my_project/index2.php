<!DOCTYPE html>
<html lang="en">
<head>
  <title>E-LAT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="aa.css">


<!---------- to disable back button -------------------------->
<script>
  function preventBack(){window.history.forward();}
  setTimeout("preventBack()", 0);
  window.onunload=function(){null};
</script>

</head>

<!---------- to disable right click ---------------------------->
<script language="javascript">
    document.onmousedown=disableclick;
    status="Right Click Disabled";
    function disableclick(event)
    {
      if(event.button==2)
       {
         return false;    
       }
    }
    </script>

<!---------- to disable copy ---------------------------->
<script language=JavaScript>

//var question_no = 1;	// this variable is for keeping the current question no. of middle section

function ieClicked() {
    if (document.all) {
        return false;
    }
}
function firefoxClicked(e) {
    if(document.layers||(document.getElementById&&!document.all)) {
        if (e.which==2||e.which==3) {
            return false;
        }
    }
}
if (document.layers){
    document.captureEvents(Event.MOUSEDOWN);
    document.onmousedown=firefoxClicked;
}else{
    document.onmouseup=firefoxClicked;
    document.oncontextmenu=ieClicked;
}
document.oncontextmenu=new Function("return false")
function disableselect(e){
    return false
    }
    function reEnable(){
    return true
    }
    document.onselectstart=new Function ("return false")
    if (window.sidebar){
    document.onmousedown=disableselect
    document.onclick=reEnable
    }
</script>

<body oncontextmenu="return false" oncopy="return false" oncut="return false" onpaste="return false" >


<!------------------------------------------ connection----------------------------->

<?php

include('mysql-connect.php');

$sql = "SELECT * FROM English";
$result = $conn->query($sql);

//$row = $result->fetch_assoc() ;

/* if ($result->num_rows > 0) 
   {
       // output data of each row
        while($row = $result->fetch_assoc()) 
	{
            echo "id: " . $row["q_id"]. "<br>";
	}
   } 
  else {
    echo "0 results";              
}*/


?> 

<nav class="navbar navbar-inverse" >
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <!-- <a class="navbar-brand" href="#">Logo</a>-->
    </div>

    
	
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">E-Lat Online Test Portal</a></li>
      </ul>
	 <!-- Trigger the modal with a button -->
	<ul class="nav navbar-nav navbar-right">
        <li><a href="#" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-list-alt"></span> Instructions</a></li>
	
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Instructions to follow</h4>
        </div>
        <div class="modal-body">
          <p>Keep on doing the good work.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
		
		<!-------------------- Left ------------------------>   


<div  class="col-sm-3 sidenav">
<div  style="background-color:#555;border-radius:10px;padding-bottom:1px;padding-top:5px">
<p class= "text-center" style="font-size:14px; color: #ffffff"><strong>Question list</strong></p>
</div>
	<div style="margin-top:10px;">
	<p style="color:black ">English </p>
	</div>
	<div  class="pre-scrollable" style="height:700px;padding-bottom:30px;border-radius:10px;">
		
		<?php	
			$n = $result->num_rows ;		
			if ($n > 0) 
  			 {
				$i = 1;
				$a=array(); 
             		     while($row = $result->fetch_assoc()) 
			     {
				$p = $row["question"] ;
				echo '<div onclick="myOverFunction(\''. $i.'\',\''. $row["question"].'\',\''. $row["op1"].'\',\''. $row["op2"].'\',\''. $row["op3"].'\',\''. $row["op4"].'\',0)" align="left" class="j" role="group" aria-label="..."  > <button id = "btnl'.$i.'"  type="button" class="btn btn-default btn-xs btn-round" style="border-radius:10px;">'.$i.'</button><p class="question" style ="display:inline; ">'.$p.'</p></div>';
				

				$a[]=$row; 	 
				$i=$i+1;
			     }
		            $b = json_encode($a[3]["question"]);
			   
			 }

		?>
          		
		

	</div>	
</div>
    
		<!------------- Middle ------------------------>
<div class="col-sm-6 text-left"> 

		<div>		
		<div class="well well-sm" style="background-color:#FFFFFF;margin-top:10px; text-align:center;">
		<button type="button" class="btn btn-info disabled" style="border-radius:5px;width:140px;" id = "Logical_reasoning">Logical Reasoning</button>
		<button type="button" class="btn btn-primary" style="border-radius:5px;width:140px;" id = "English" >English</button>
		<button type="button" class="btn btn-info disabled"style="border-radius:5px;width:140px;" id = "Optional " >Optional</button>
		</div>  


		<div class="pre-scrollable" style="height:70%;background-color:#FFFFFF;border-radius:10px;padding-bottom:40px;margin-top:20px;">

		<?php 
			$sql = "SELECT * FROM English ";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
			


			function php_function()
			{
				
				//document.getElementById("rahul").innerHTML =question_no ;
				$sqlp = "SELECT * FROM question WHERE q_no = question_no";
			//	$resultp = $conn->query($sqlp);
				//$rowp = $resultp->fetch_assoc();

			}
		?>
			
			
		<!---Timer starts----------->
		<div >
		
		<strong>Question: <p style="display:inline" id= "demo_q_no"  > <?= $row["q_no"]; ?></p></strong>	
		<p  style="display:inline; padding-left:60%;" align:"right"><strong>Time left: </strong><p style="display:inline" id="countdown">00:10</p></p>
		</div>
			
		 
		<!---Timer ends------------>

		

		

		
		<div class="question_box">
			<p id= "demo_question"> <?= $row["question"]; ?></p>
		</div>
		
		<p id="rahul">Rahul</p>
		<p ><strong>Options:</strong></p>
		
		<form action="">
  		<input type="radio" name="option" value="A"> <level id= "demo_op1" > A. <?= $row["op1"]; ?></level></br>
 		<input type="radio" name="option" value="B"> <level id= "demo_op2" > B.  <?= $row["op2"]; ?></level><br>
  		<input type="radio" name="option" value="C"> <level id= "demo_op3" > C.  <?= $row["op3"]; ?></level><br>
		<input type="radio" name="option" value="D"> <level id= "demo_op4" > D.  <?= $row["op4"]; ?></level>
		</form>


		</div> 

 	<div style="margin-top:20px;">
	<button type="button" class="btn btn-primary" style="border-radius:5px;width:150px;">Mark for Review</button>
	<button type="button" class="btn btn-primary" style="border-radius:5px;width:150px;display:inline;margin-left:3px;">Clear Response</button>
	<button  onclick = "saveNext()"  type="button" class="btn btn-success " style="border-radius:5px;width:150px;display:inline;margin-left:50px;">Save & Next  <span class="glyphicon glyphicon-arrow-right"></span></button>


	</div>

</div>	 
</div>

		<!------------- Right----------------------->
    <div class="col-sm-3 sidenav">
            	<div  class="pre-scrollable"  style="height:55% ;" >
 	 <p style="color:black">ANSWER SHEET</p>
   <?php
    for($i=1;$i <= $n;$i++)
    {
    echo '<button id = "btnr'.$i.'" type="button" class="btn btn-default" style="border-radius:20px;width:40px;margin-left:7px;margin-top:7px;">'.$i.'</button>' ;
    }
   ?>


      </div>
     
 <div class="jumb">
	
	<button type="button" class="btn btn-default" style="mrgin-left:0px;" ><p style="font-size:10px;"> Not Visited</p></button>
	<button type="button" class="btn btn-success"style="mrgin-left:3px;"><p style="font-size:10px;">Answered</p></button>
	<button type="button" class="btn btn-danger" style="display:inline"><p style="font-size:10px;">Not Answered</p></button>
	<button type="button" class="btn btn-primary" style="display:inline"><p style="font-size:10px;">Marked</p></button>
	<button type="button" class="btn btn-warning" style="display:inline"><p style="font-size:10px;">Marked & Answered</p></button>
    	
  </div>
	<div style="margin-top:20px;">
	
	<button type="button" class="btn btn-danger"><span class="glyphicon glyphicon-off"></span> Finish Test</button>
	<div>
    </div>
  </div>
</div>

<div class="navbar-fixed-bottom" style="padding-top:1%;width:100%;background-color:#555;height:35px;color:#FFFFFF;position:absolute;bottom:0px;text-align:right;padding-right:2%;">  Powered by Appexigo Technogies</div>
  

	
<script>
	function myOverFunction(x,ques,op1,op2,op3,op4) {
		
    		
			document.getElementById("demo_q_no").innerHTML = x;
			document.getElementById("demo_question").innerHTML = ques;
			document.getElementById("demo_op1").innerHTML = "A. "+op1;
			document.getElementById("demo_op2").innerHTML = "B. "+op2;
			document.getElementById("demo_op3").innerHTML = "C. "+op3;
			document.getElementById("demo_op4").innerHTML = "D. "+op4;
			document.getElementById("btnl"+x).style.backgroundColor = "#d9534f";
			document.getElementById("btnr"+x).style.backgroundColor = "#d9534f";
			question_no = x;

		
		
	}

	

//--------------------------timer-------------------------------------------

var seconds = 9;

function secondPassed() {
    var minutes = Math.round((seconds - 30)/60);
    var remainingSeconds = seconds % 60;
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds;  
    }
    
    if (minutes < 10) {
        minutes = "0" + minutes;  
    }
    document.getElementById('countdown').innerHTML = minutes + ":" + remainingSeconds;
    if (seconds == 0) {
        clearInterval(countdownTimer);
	alert("This section completed..!!");   
	
        window.open("index3.php","_self")
	
    } else {
        seconds--;
    }
}
 
var countdownTimer = setInterval('secondPassed()', 1000);

function timer()
{	
	//document.getElementById("countdown").innerHTML = "";
}

//---------------------------timer ends-------------------------------------------
</script>



<?php
$conn->close();
?>

</body>
</html>
