<?php
$q_no = check_input($_POST['q_no']);
$q_id    = check_input($_POST['q_id']);

?>



<?php
function check_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

